#player_actions.py


def check_play_again(user_input):
    #Your code here


check_play_again(input("Would you like to play again? Type Y for Yes or N for No: \n"))
